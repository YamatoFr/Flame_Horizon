import pygame as pg
from Class import *
from Dico import *
import os
pg.font.init()
pg.init()


largeur, hauteur = 1300, 650
fenetre = pg.display.set_mode((largeur,hauteur))
horloge = pg.time.Clock()
fps = 30
i = 1
State = "Menu"
select = 1
ennemies = []
a=100
niveau = 1

perso = Perso(fenetre, images['vaisseau1'],240, 300)
ennemis = Ennemis(fenetre, images['tribase1_nor'], largeur+20,randint(0,hauteur+20))
meteorite = Meteorite(fenetre, images['astéroide'], randint(0, largeur), randint(0, hauteur//hauteur))
fond_0 = ElementGraphique(fenetre, images['fond_0'], 0, 0)
fond_1 = ElementGraphique(fenetre, images['fond_1'], 0, 0)
txt_play = ElementGraphique(fenetre, ecriture['play'], 500, 140)
txt_quit = ElementGraphique(fenetre, ecriture['quit'], 520, 350)
txt_vie = ElementGraphique(fenetre, ecriture['vie'],50, 500)
tirs = []
last_tirs = 0



while State:
	horloge.tick(60)
	i += 1
	touches = pg.key.get_pressed()
	for event in pg.event.get():   
		if event.type==pg.QUIT:     
			State=False
		if touches [pg.K_ESCAPE]:
			State=False


	if State == "Menu":
		fond_0.afficher()
		txt_play.afficher()
		txt_quit.afficher()

		if touches [pg.K_DOWN]:
			select += 1
		if touches [pg.K_UP]:
			select -= 1
		if select == 1 :
			fenetre.blit(ecriture['play_select'],(500,140))
			if touches [pg.K_RETURN]:
				State = "Jeu"
		if select == 2 :
			fenetre.blit(ecriture['quit_select'],(520,350))
			if touches [pg.K_RETURN]:
				State = False
		if select == 0 :
			select = 2
		if select == 3 :
			select = 1    


	if State == "Jeu":
		fond_1.afficher()
		#txt_vie.afficher()
		perso.afficher()
		perso.deplacer(touches, largeur, hauteur)
		
		if touches[pg.K_l] and i-last_tirs>30:
			tir(tirs, images, i, fps, 1, perso)
			last_tirs = i

		for t in tirs:
			t.deplacer()
			t.afficher()
			#for ennemie in ennemies:
				#ennemie.collision(t, tirs)
			

		if len(ennemies)<8 :
			a = ajouter(i, hauteur, largeur, images, ennemies,a)

		State = perso.en_vie()

		for ennemie in ennemies :
			ennemie.move()
			ennemie.afficher()
			#perso.collision(ennemie, ennemies)
			#ennemie.en_vie(ennemies)

			

		
			

	pg.display.flip()
pg.quit()