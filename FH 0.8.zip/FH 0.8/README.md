# Flame_Horizon

Version 0.7:<br/>
-Ajout Animation<br/>
-Corrigé images tirs<br/>
-Corrigé animation<br/>

Version 0.6:<br/>
-Ajout class Tirs<br/>
-Ajout def tirs/tirs<br/>
-Essai animation<br/>
-TODO : correction bug avec animation<br/>

Version 0.5:<br/>
-Ajout class ElementAnime<br/>
-Ajout images dans images/tirs<br/>
-Retrait fond des images png<br/>
-Correction dictionnaires<br/>
